import * as React from 'react';
import { Button, View, Text } from 'react-native';
function Home3({ navigation }) {
  return (


    
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>News</Text>
    </View>);



}
export default Home3;