import * as React from 'react';
import { Button, View,TouchableOpacity ,StyleSheet, Text } from 'react-native';
function Home4({ navigation }) {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>Settings</Text>
      <TouchableOpacity  style={styles.loginBtn} 
        onPress = { ()=>navigation.navigate('Signup')}
        >
          <Text style={styles.loginText} >Signup</Text> 
        </TouchableOpacity>
     
    </View>
  );


}
export default Home4;

const styles = StyleSheet.create({
    loginBtn:{
      width:"80%",
      backgroundColor:"#000000",
      borderRadius:10,
      height:40,
      alignItems:"center",
      justifyContent:"center",
      marginTop:7,
      marginBottom:5
    },
   
  });