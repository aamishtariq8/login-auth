import * as React from 'react';
import { Button, View,Text } from 'react-native';

function Home1  ({ navigation }) {
  return (

    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>Fixtures</Text>
    </View>
  );
}
export default Home1;
