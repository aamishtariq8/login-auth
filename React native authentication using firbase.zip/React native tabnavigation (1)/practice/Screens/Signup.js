import * as React from 'react';
import { StyleSheet, Text, View, TextInput, Button,Alert ,Image, TouchableOpacity } from 'react-native';
import { FontAwesome } from '@expo/vector-icons';
import {createUserWithEmailAndPassword,signInWithEmailAndPassword} from "firebase/auth"
import {auth} from "./config"
function Signup({ navigation }) {



    const [email, setEmail] = React.useState('');
    const [password, setPassword] = React.useState('');
    //const [username, setUsername] = React.useState('');
    const handleSignUp = async () => {
      try{
    const user = await createUserWithEmailAndPassword(auth,email,password);
    // Alert.alert(
    //   "Account Created",
    //   "Press OK to Continue",
    //   [
    //     {
    //       text: "Cancel",
    //       onPress: () => console.log("Cancel Pressed"),
    //       style: "cancel"
    //     },

    //     { text: "OK", onPress: () => console.log("OK Pressed")
      
    //   }

        
    //   ]
    // );

     navigation.navigate ('Home');
  
      }catch{
       Alert.alert(
          "Alert",
          "Enter Valid Email or Password",
          [
            {
              text: "Cancel",
              onPress: () => console.log("Cancel Pressed"),
              style: "cancel"
            },
            { text: "OK", onPress: () => console.log("OK Pressed") }
          ]
        );
console.log("not created");
    
      }
    }
  return (
 
    <View style={styles.container}>
        <Image style= {styles.logo} source={require('./HomeScreens/LoginImage.png')} />
       <View ><Text style={styles.text}>Hey, SignUp to Continue</Text></View> 
        <View style={styles.inputView} >
         
          <TextInput  
            style={styles.inputText}
            placeholder="Username" 
            placeholderTextColor="#000000"
           //onChangeText={username => setUsername(username)}
         //   value={username}
           />
        </View>
        <View style={styles.inputView} >
          <TextInput  
        
            style={styles.inputText}
            placeholder="Email" 
            placeholderTextColor="black"
           onChangeText={email => setEmail(email)}
           value={email}
           />
        </View>
        <View style={styles.inputView} >
          <TextInput  
            secureTextEntry
            style={styles.inputText}
            placeholder="Password" 
            placeholderTextColor="black"
            onChangeText={password => setPassword(password)}
            value={password}
           />
        </View>

       
        <TouchableOpacity  style={styles.loginBtn} 
        onPress={handleSignUp}
       >
          <Text style={styles.loginText}>Signup</Text> 
        </TouchableOpacity>
     
  
      

      
      </View>
  
  );
}
export default Signup;

const styles = StyleSheet.create({
  container: {
    flex: 2,
    backgroundColor:"#fb5b5a",
    alignItems: 'center',
    justifyContent: 'center',
  },
  text:
  { 
  fontSize:20,
  color:"black",
  marginBottom:10
},
  
  logo:{
    width: 250,
    height: 200,
    marginBottom:20,
    resizeMode: 'contain'
  },
  inputView:{
    width:"80%",
    backgroundColor:"#fb8a5a",
    borderRadius:10,
    borderWidth: 1,
    borderColor: "#fb8a5a" ,
    height:45,
    marginBottom:20,
    justifyContent:"center",
    padding:20
  },
  inputText:{
    height:50,
    color:"black"
  },
  forgot:{
    color:"black",
    fontSize:11
  },
  loginBtn:{
    width:"80%",
    backgroundColor:"#000000",
    borderRadius:10,
    height:40,
    alignItems:"center",
    justifyContent:"center",
    marginTop:7,
    marginBottom:5
  },
  loginText:{
    color:"white"
  }
});