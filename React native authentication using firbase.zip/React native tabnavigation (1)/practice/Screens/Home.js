import * as React from 'react';
import { Button, View, Text } from 'react-native';
import Home1 from './../Screens/HomeScreens/Fixtures';
import Home2 from './../Screens/HomeScreens/LiveScores';
import Home3 from './../Screens/HomeScreens/News';
import Home4 from './../Screens/HomeScreens/Settings';
import { NavigationContainer} from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
//const Tab = createBottomTabNavigator();
import { Ionicons } from '@expo/vector-icons';


const Tab = createBottomTabNavigator();

const TAB_ICON = {
  Fixtures: "md-calendar",
  News: "md-book",
  Settings: "md-settings",
};


const createScreenOptions = ({ route }) => {
  const iconName = TAB_ICON[route.name];
  return {
    tabBarIcon: ({ size, color }) => (
      <Ionicons name={iconName} size={size} color={color} />
    ),
  };
};

export default function Home() {
  return (
     
            <Tab.Navigator
              screenOptions={createScreenOptions
               }
              tabBarOptions={{
                       activeTintColor: '#fff',
                       inactiveTintColor: 'lightgray',
                       activeBackgroundColor: '#c4461c',
                       inactiveBackgroundColor: 'black',
                           style: {
                                 backgroundColor: 'white',
                                 paddingBottom: 15
                           }
                          }   
                         }
                 >
              <Tab.Screen 
               options={{
                headerStyle: {
                  backgroundColor: 'black',
                   
                },
                headerTintColor: 'white',
                headerTitleAlign : 'center',
                headerTitleStyle: {
                  fontWeight: 'bold',
                },
             
              }}
              name="Fixtures" component={Home1} />
              <Tab.Screen
               options={{
                headerStyle: {
                  backgroundColor: 'black',
                   
                },
                headerTintColor: 'white',
                headerTitleAlign : 'center',
                headerTitleStyle: {
                  fontWeight: 'bold',
                },
             
              }}
               name="News" component={Home3} />
              <Tab.Screen 
               options={{
                headerStyle: {
                  backgroundColor: 'black',
                   
                },
                headerTintColor: 'white',
                headerTitleAlign : 'center',
                headerTitleStyle: {
                  fontWeight: 'bold',
                },
             
              }}
              name="Settings" component={Home4} />
            
            </Tab.Navigator>

         
  
  );
}










// function Home() {
//    return(
//    //<NavigationContainer>
//     <Tab.Navigator
   
//       tabBarOptions={{

      
         
//        activeTintColor: '#fff',
//        inactiveTintColor: 'lightgray',
//        activeBackgroundColor: '#c4461c',
//        inactiveBackgroundColor: 'black',
//            style: {
//                  backgroundColor: 'white',
//                  paddingBottom: 15
//            }
//           }

     
    
//   }
 
//     >
//       <Tab.Screen name="Fixtures" component={Home1} 
//     options={{
//       headerStyle: {
//         backgroundColor: 'black',
         
//       },
//       headerTintColor: 'white',
//       headerTitleAlign : 'center',
//       headerTitleStyle: {
//         fontWeight: 'bold',
//       },
//    ,
//     }}
//     />
      
//       <Tab.Screen  options={{
//       headerStyle: {
//         backgroundColor: 'black', 
//       },
//       headerTintColor: 'white',
//       headerTitleAlign : 'center',
     
//       headerTitleStyle: {
//         fontWeight: 'bold',
//       },
//       tabBarIcon: ({ color }) => (
//         <Ionicons name="home" color={color} size={26} />
//       ),
//     }}
//     name="LiveScores" component={Home2} />
//       <Tab.Screen  options={{
//       headerStyle: {
//         backgroundColor: 'black',    
//       },
//       headerTintColor: 'white',
//       headerTitleAlign : 'center',
     
//       headerTitleStyle: {
//         fontWeight: 'bold',
     
//       },
//       tabBarIcon: ({ color }) => (
//         <Ionicons name="home" color={color} size={26} />
//       ),
//     }}
//     name="News" component={Home3} />
//       <Tab.Screen  options={{
//       headerStyle: {
//         backgroundColor: 'black',
         
//       },
//       headerTitleAlign : 'center',
//       headerTintColor: 'white',
//       headerTitleStyle: {
//         fontWeight: 'bold',
//       },
//       tabBarIcon: ({ color }) => (
//         <Ionicons name="home" color={color} size={26} />
//       ),
//     }}
   
//    name="Settings" component={Home4} />
//     </Tab.Navigator>
//    // </NavigationContainer>
   
//    );
// }
// export default Home;



 //   screenOptions={({ route }) => ({
  //     tabBarStyle: {
  //       height: 50,
  //       paddingHorizontal: 5,
  //       paddingTop: 0,
  //       backgroundColor: 'black',
  //       borderTopWidth: 0,
  //       activeTintColor: '#fff',
  //       inactiveTintColor: 'lightgray',
  //       activeBackgroundColor: '#c4461c',
  //       inactiveBackgroundColor: '#b55031',
  //           style: {
  //                 backgroundColor: '#CE4418',
  //                 paddingBottom: 3
  //           }
  //   },
  //     backgroundColor: 'black',
  //     headerStyle: {
  //      backgroundColor: 'black',
      
  //     },
  //     headerTintColor: 'white',
  //     headerTitleStyle: {
  //       fontWeight: 'bold',
  //     },

  // })}
  // tabBarOptions={{
  //   activeTintColor: 'tomato',
  //   inactiveTintColor: 'gray',
  //   showLabel: false,
  //   style: {backgroundColor: black,},
  // }}
  